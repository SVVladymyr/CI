<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Articles</title>
	<style type="text/css">

	::selection{ background-color: #E13300; color: white; }
	::moz-selection{ background-color: #E13300; color: white; }
	::webkit-selection{ background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	table {
		border: 4px double black;
  		border-collapse: collapse;
	}

	th {
		text-align: center;
    	background: #ccc;
    	padding: 5px;
    	border: 1px solid black;
	}

	td {
		text-align: center;
		border: 1px solid;
	}

	a {
		color: #003399;
		background-color: transparent;
		font-weight: normal;
	}

	h1 {
		color: #444;
		background-color: transparent;
		border-bottom: 1px solid #D0D0D0;
		font-size: 19px;
		font-weight: normal;
		margin: 0 0 14px 0;
		padding: 14px 15px 10px 15px;
	}

	#body{
		margin: 0 15px 0 15px;
	}
	
	footer{
		text-align: center;
		font-size: 11px;
		border-top: 1px solid #D0D0D0;
		line-height: 32px;
		padding: 0 10px 0 10px;
		margin: 20px 0 0 0;
	}
	
	</style>
</head>
<body>
	<table>
		<caption><h1>Articles</h1></caption>
		<tr>
			<th>Title</th>
			<th>Data</th>
            <th>Content</th>
			<th>Author</th>
			<th>The number of views</th>
		</tr>