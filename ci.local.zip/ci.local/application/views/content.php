<tr>
        <td><?php echo $title ?></td>
        <td><?php echo $date ?></td>
        <td><?php echo $text ?></td>
        <td><?php echo $author ?></td>
        <td><?php echo $count ?></td>
	</tr>