	<tr>
                <td><?php echo $author ?></td>
                <td><?php echo $date ?></td>
                <td><?php echo $text ?></td>
	</tr>