<div id="add-comment">
	<?php echo validation_errors(); ?>
	<?php echo form_open('articles/add_comment');?>
	<?php echo form_hidden('id', $id); ?>
	<?php echo form_label('Name', 'name'); ?>
	<br>
	<?php echo form_input('name'); ?>
	<br>
	<?php echo form_label('Comment', 'comment'); ?>
	<br>
	<?php echo form_textarea('comment'); ?>
	<br>
	<?php echo form_submit('mysubmit', 'Add Comment!'); ?>
</div>