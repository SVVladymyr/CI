<div id="comment">
    <table>
        <caption><h1>Comment</h1></caption>
		<tr>
			<th>Author</th>
			<th>Date</th>
            <th>Comment</th>
		</tr>