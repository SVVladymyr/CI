	<tr>
                <td><?php echo anchor('articles/view_article/'.$id,$title); ?></td>
                <td><?php echo $about ?></td>
                <td><?php echo $date ?></td>
                <td><?php echo $countComment ?></td>
                <td><?php echo $count ?></td>
	</tr>