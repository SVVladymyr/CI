<?php
    class Comments_model extends CI_Model {

        var $idArticle   = '';
        var $author      = '';
        var $text        = '';
        var $date        = '';

        function __construct()
        {
            // вызываем конструктор модели
            parent::__construct();
        }
        
        function get_comments($id)
        {
            $query = $this->db->get_where('comments', array('idArticle' => $id));
            return $query->result();
        }

        function get_lists_comments($field = FALSE)
        {
            if($field != FALSE) 
            {
                $this->db->order_by($field, 'desc'); 
            }
			$query = $this->db->get('comments');
			
            return $query->result();
        }

        function insert_comments()
        {
            $this->text        = htmlspecialchars($this->input->post('comment'));
            $this->idArticle   = htmlspecialchars($this->input->post('id'));
            $this->author      = htmlspecialchars($this->input->post('name'));
            $this->date        = date("Y-m-d");

            $this->db->insert('comments', $this);
        }

        function update_comments()
        {
            $this->text    = htmlspecialchars($this->input->post('text'));
            $this->date    = date("Y-m-d");

            $this->db->update('comments', $this, array('id' => $this->input->post('id')));
        }

        function delete_comments()
        {
            $this->db->delete('comments', array('id' => $this->input->post('id'))); 
        }
		
		function count_comments($id)
		{
			$this->db->where('idArticle', $id);
			
			return $this->db->count_all_results('comments');
		}
    }
    
?>