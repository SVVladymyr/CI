<?php
    class Articles_model extends CI_Model {

        var $title   = '';
        var $text = '';
        var $about = '';
        var $author = '';
        var $count = 0;
        var $date    = '';

        function __construct()
        {
            // вызываем конструктор модели
            parent::__construct();
            $this->load->database();
        }
        
        function get_articles($id)
        {
			$query = $this->db->get_where('articles', array('id' => $id));
            return $query->result();
        }



        function get_lists_articles($field = FALSE, $num, $offset)
        {
            if($field != FALSE)
            {
                $this->db->order_by($field, 'desc'); 
            }
            $query = $this->db->get('articles',$num, $offset);
            
            return $query->result();
        }

        function insert_articles()
        {
            $this->title   = htmlspecialchars($this->input->post('title'));
            $this->text    = htmlspecialchars($this->input->post('text'));
            $this->about   = htmlspecialchars($this->input->post('about'));
            $this->author  = htmlspecialchars($this->input->post('author'));
            $this->date    = date("Y-m-d");

            $this->db->insert('articles', $this);
        }

        function update_articles()
        {
            $this->title   = htmlspecialchars($this->input->post('title'));
            $this->text    = htmlspecialchars($this->input->post('text'));
            $this->date    = date("Y-m-d");

            $this->db->update('articles', $this, array('id' => $this->input->post('id')));
        }

        function delete_articles()
        {
            $this->db->delete('articles', array('id' => $this->input->post('id'))); 
        }

		function get_count($result)
		{
			foreach($result as $value)
			{
				$data = array(
					'id' => $value->id,
					'title' => $value->title,
					'about' => $value->about,
					'text' => $value->text,
					'date' => $value->date,
					'author' => $value->author,
					'count' => $value->count,
				);
			}
			return $data;
		}
		
		function update_count($data)
		{
			$count = (int) $data['count'];
			$data['count']   = $count + 1;
			
            $this->db->update('articles', $data, array('id' => $data['id']));
		}
    }
    
?>