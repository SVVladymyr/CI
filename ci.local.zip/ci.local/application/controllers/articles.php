<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Articles extends CI_Controller {

	function __construct() 
	{ 
         parent::__construct(); 

         $this->load->helper('form'); 
		 $this->load->helper('url');
		 $this->load->model('Articles_model');
		 $this->load->model('Comments_model');
		 $this->load->driver('cache');
    } 

	public function index($field = FALSE)
	{
		$this->load->library('pagination');
		$this->db->cache_on();
		
		$config['base_url'] = site_url('/articles/index/');
		$config['total_rows'] = $this->db->count_all('articles');;
		$config['per_page'] = 5; 
		$this->pagination->initialize($config);
		
        $result = $this->Articles_model->get_lists_articles($field, $config['per_page'], $this->uri->segment(3));
		$this->load->view('head');
		$this->output_articles($result, 'article');
		$this->load->view('footer_table');
		$this->load->view('pagination');
		$this->load->view('footer');
	}

	public function view_article($id)
	{

        $this->db->cache_delete();
		$result = $this->Articles_model->get_articles($id);
		$this->add_count($result);
		
		$this->load->view('head_content');
		
		$this->output_articles($result, 'content');

		$this->load->view('footer_table');

		/*
		*	Output comment block
		*/
		
		$this->output_comments($this->Comments_model->get_comments($id));
		
		/*
		*	End block output comment
		*/

		$data = array(
			'id' => $id
		);
		$this->load->view('addComment', $data);
		$this->load->view('footer');
	}
	
	public function add_comment()
	{
	  
	  	$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');

		$this->form_validation->set_rules('name', 'Имя пользователя', 'trim|required|min_length[3]|max_length[12]|xss_clean');
		$this->form_validation->set_rules('comment', 'Комментарий', 'trim|required');

	    if ($this->form_validation->run() === TRUE) {
			$this->Comments_model->insert_comments();
		    $this->view_article($this->input->post('id'));
  	    } else {
			$this->view_article($this->input->post('id'));
		}
	}

	private function output_comment($result)
	{
		foreach($result as $value)
		{
			$data = array(
				'id' => $value->id,
				'text' => $value->text,
				'date' => $value->date,
				'author' => $value->author,
			);
			$this->load->view('comment', $data);
		}
	}
	
	private function output_articles($result, $viewContent)
	{
		foreach($result as $value)
		{
			$data = array(
				'id' => $value->id,
				'title' => $value->title,
				'about' => $value->about,
				'text' => $value->text,
				'date' => $value->date,
				'author' => $value->author,
				'count' => $value->count,
				'countComment' => $this->Comments_model->count_comments($value->id),
			);
			$this->load->view($viewContent, $data);
		}
	}
	
	private function add_count($result)
	{
		$data = $this->Articles_model->get_count($result);
		$this->Articles_model->update_count($data);
	}
	
	private function output_comments($result)
	{
		$this->output->cache(30);
		$this->load->view('head_table_comment');
		$this->output_comment($result);
		$this->load->view('footer_table_comment');
	}
}

?>