-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 18 2017 г., 20:45
-- Версия сервера: 5.7.16
-- Версия PHP: 7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ci`
--

-- --------------------------------------------------------

--
-- Структура таблицы `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `title` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `about` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `text` text CHARACTER SET utf8 NOT NULL,
  `author` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `count` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `articles`
--

INSERT INTO `articles` (`id`, `title`, `about`, `text`, `author`, `count`, `date`) VALUES
(1, 'Microsoft начала блокировку обновлений для владельцев новых процессоров и старых версий Windows', 'Мы уже сообщали читателям о том, что корпорация Microsoft собирается в принудительном порядке пересаживать владельцев процессоров Intel Kaby Lake, AMD Ryzen, а также последующих за ними моделей путём отказа предоставления обновлений для операционных систем Windows с номером версии меньше 10.', 'Мы уже сообщали читателям о том, что корпорация Microsoft собирается в принудительном порядке пересаживать владельцев процессоров Intel Kaby Lake, AMD Ryzen, а также последующих за ними моделей путём отказа предоставления обновлений для операционных систем Windows с номером версии меньше 10. Очень и очень многие пользователи продукции программного гиганта этим весьма недовольны, но выбора у них нет, поскольку процедура перехода на другую операционную систему — занятие долгое и кропотливое, а времени у занятых работой людей не всегда достаточно. К сожалению, это тот случай, когда Microsoft аккуратно выполнила обещанное. Если в случае с AMD Ryzen такую политику можно было бы списать на новизну архитектуры, то с Kaby Lake такой номер не пройдет, поскольку эта архитектура почти не отличается от Skylake. К слову, обладатели Skylake и Excavator таких сообщений не получают. Иными словами, причины чисто маркетинговые. Среди прочих побуждений Microsoft можно назвать стремление к унификации инфраструктуры программного обеспечения. Унификация — почти всегда вещь хорошая, но не тогда, когда владельцев ПК «железной рукой загоняют в светлое будущее», особенно без их ведома и желания. Следует помнить, куда именно благими намерениями вымощена дорога. Даже без оглядки на информационную безопасность такое поведение со стороны MS по-человечески невежливо и граничит с откровенным хамством. А ведь это ещё не всё: с выпуском Anniversary Update компания объявила о том, что больше не будет обновлять оригинальную версию Windows 10. И не исключено, что аналогичный сценарий ждёт и Creators Update.', 'Алексей Степин', 0, '2017-04-17');

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `author` varchar(1000) NOT NULL,
  `text` text NOT NULL,
  `date` date NOT NULL,
  `idArticle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `author`, `text`, `date`, `idArticle`) VALUES
(1, 'vova', 'vvv', '2017-04-18', 1),
(2, 'vova', 'ccc', '2017-04-18', 1),
(3, 'vova', 'ccc', '2017-04-18', 1),
(4, 'test', 'tedsfsdddddddddddddddddddddddddddddddddddddddddddddddvvvvvvvvvvvvvvvvvvvvvvvvvvv', '2017-04-18', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
